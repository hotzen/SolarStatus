# http://www.richardelling.com/Home/scripts-and-programs-1/zilstat
ksh /opt/zilstat.ksh -M -t 1 3