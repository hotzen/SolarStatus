# http://cuddletech.com/arc_summary/
perl /opt/arc_summary.pl 

# or try another version:
# http://code.google.com/p/jhell/source/browse/base/head/scripts/zfs/arc_summary/arc_summary.pl

