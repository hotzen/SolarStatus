# http://www.solarisinternals.com/wiki/index.php/Arcstat
# http://code.google.com/p/jhell/source/browse/base/head/scripts/zfs/arcstat/arcstat.pl
perl /opt/arcstat.pl  1 3