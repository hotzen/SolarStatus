#svcs -a -o state,stime,fmri
svcs