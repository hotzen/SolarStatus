# iostat -dcnx 1 2
iostat -dnx 1 2