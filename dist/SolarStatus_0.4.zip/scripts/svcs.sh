svcs
#svcs -a -o state,stime,fmri