# iostat -DCnx 1 2
iostat -Dnx 1 2
