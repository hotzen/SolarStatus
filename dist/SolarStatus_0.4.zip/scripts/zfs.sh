zfs list -t fs -o name,used,avail,mountpoint,sharesmb,sharenfs,keystatus
