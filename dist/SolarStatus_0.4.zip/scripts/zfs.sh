zfs list -o name,used,avail,mountpoint,sharesmb,sharenfs
