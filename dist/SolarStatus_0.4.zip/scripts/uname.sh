uname --all
