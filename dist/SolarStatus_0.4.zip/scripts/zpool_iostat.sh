# zpool iostat -v 1 2
zpool iostat 1 2
