vmstat 1 2
