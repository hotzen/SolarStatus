SolarStatus.view("ipadm_if", function(cmd, rc, out, createView, done) {
/*
function solar_transform_ipadm_if(elem, cmd, rc, out) {
	var tbl = new TableTransformer()
	
	// TODO
	
	tbl.create(out, elem)
	
	return "Table"
}
*/
})