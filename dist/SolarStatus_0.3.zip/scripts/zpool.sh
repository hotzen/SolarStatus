zpool status -v
