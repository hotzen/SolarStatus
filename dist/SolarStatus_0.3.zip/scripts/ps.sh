ps -e -o pid -o user -o s -o pcpu -o pmem -o vsz  -o stime -o comm
#ps -e -o pid -o user -o s -o pcpu -o vsz  -o stime -o args
#ps axuw