mpstat 1 2
