# http://www.brendangregg.com/Perf/network.html#nicstat
nicstat 1 2